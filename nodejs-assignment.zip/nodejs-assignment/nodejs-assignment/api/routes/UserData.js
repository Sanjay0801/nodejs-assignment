const users = [

    {
  
      id: 1,
  
      name: "John",
  
      email: "john@gmail.com",

      password:"john123"
  
    },
  
    {
  
      id: 2,
  
      name: "Smith",
  
      email: "smith@gmail.com",

      password:"smith"
  
    },
  
    {
  
      id: 3,
  
      name: "Chris",
  
      email: "chris@gmail.com",

      password:"chris"
  
    },
  
    {
  
      id: 4,
  
      name: "Jack",
  
      email: "jack@gmail.com",

      password:"jack"
  
    }
  
  ];

  module.exports = users;